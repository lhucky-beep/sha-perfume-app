SHA PERFUME - NEW GITHUB PROJECT
Build cloud via GitHub Actions.

Features:
- Responsive mobile UI
- 9 website-matching products and prices
- Search
- Favorites with localStorage
- Cart
- Checkout
- WhatsApp order to 62895323164524
- Profile, order status, about, help
- No backend/payment gateway; orders are sent to WhatsApp

GitHub Actions workflow is included in .github/workflows/build-apk.yml.
