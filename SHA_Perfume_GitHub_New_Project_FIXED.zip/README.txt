SHA PERFUME Android project.
Build using GitHub Actions. No AndroidX dependencies; this avoids dependency resolution problems.
Features: responsive UI, products, search, favorites, cart, checkout and WhatsApp.
WhatsApp: 62895323164524
